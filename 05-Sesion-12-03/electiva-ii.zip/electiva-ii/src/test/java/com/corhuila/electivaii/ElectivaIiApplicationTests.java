package com.corhuila.electivaii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectivaIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
